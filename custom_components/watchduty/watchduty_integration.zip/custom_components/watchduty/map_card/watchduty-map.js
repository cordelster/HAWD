// JS for WatchDuty map card with zoom to fit
