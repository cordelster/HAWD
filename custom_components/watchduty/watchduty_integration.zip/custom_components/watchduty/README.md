# WatchDuty Wildfire Alerts

Integration for Home Assistant to show wildfire alerts on a map.